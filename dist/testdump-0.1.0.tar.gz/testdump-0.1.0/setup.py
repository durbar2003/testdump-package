from setuptools import setup

VERSION = '0.1.0'

setup(
    name="testdump",
    version='0.1.0',
    author="Durbar Chakraborty",
    author_email="durbardibyo@gmail.com",
    install_requires=['prometheus_client >= 0.14.1']
)
